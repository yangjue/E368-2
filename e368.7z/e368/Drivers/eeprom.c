#include "eeprom.h"

#include <stdio.h>

#include "board.h"

#include "Drivers/SPI/spiDriver.h"

#define EEPROMSPIBlockSize 48 
const unsigned short eepromId[] = {0x9F, 0x00, 0x00, 0x00};
const unsigned short eepromWren = 0x06;
unsigned short eepromSe[] = {0x20, 0x00, 0x00, 0x00}; //erases sector 0
const unsigned short eepromRdsr[] = {0x05, 0x00};
//unsigned short eepromPp[12] = {0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
unsigned short eepromRead[12] = {0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//unsigned short eepromRx[12];
unsigned short eepromPp[100] = {0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
unsigned short eepromRx[100];
//void saveIp(unsigned char *ip);
//void getIp(unsigned char *ip);
//void getIpInit(unsigned char *ip);
static int ceil(double d);
void saveMac(unsigned char *mac);
void getMac(unsigned char *mac);
void getMacInit(unsigned char *mac);

//get ip/set ip commands, if the ip exists then we use it
//otherwise we use DHCP
//mac is expected to be 6 bytes
/*void saveIp(unsigned char *ip) {
	int i;
	//copy ID to eeprom
	for (i = 0; i < 4; i++)
		eepromPp[i+4] = ip[i];
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//erase page
	eepromSe[1] = 0x00;
	eepromSe[2] = 0x20;
	eepromSe[3] = 0x00;
	vSPIDoTransfer(1, eepromSe, eepromRx, 4, NULL);
	//wait for finish
	do {
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//write page
	eepromPp[1] = 0x00;
	eepromPp[2] = 0x20;
	eepromPp[3] = 0x00;
	vSPIDoTransfer(1, eepromPp, eepromRx, 8, NULL);	
	//wait for finish
	do {
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
}*/

/*void getIpInit(unsigned char *ip) {
    int i;
	//read page
	eepromRead[1] = 0x00;
	eepromRead[2] = 0x20;
	eepromRead[3] = 0x00;
	vSPIDriverTransaction(1, eepromRead, eepromRx, 8);
	for (i = 0; i < 4; i++)
	    ip[i] = eepromRx[i+4];
	//wait for NSS to rise
	while (AT91C_BASE_SPI0->SPI_SR & (1 << 8));
}*/

/*void getIp(unsigned char *ip) {
    int i;
	//read page
	eepromRead[1] = 0x00;
	eepromRead[2] = 0x20;
	eepromRead[3] = 0x00;
	vSPIDoTransfer(1, eepromRead, eepromRx, 8, NULL);
	for (i = 0; i < 4; i++)
	    ip[i] = eepromRx[i+4];
}*/

/*void cmd_setip(char *arg) {
    unsigned int ipl[4];
    unsigned char ip[4];
    int i;
    if (sscanf(arg, "%i.%i.%i.%i", (ipl + 0), (ipl + 1), (ipl + 2), (ipl + 3)) != 4) {
        printf("Unable to parse IP address\r\n");
        return;
    }
    for (i = 0; i < 4; i++)
        ip[i] = ipl[i] & 0xff;
    
    saveIp(ip);
    printf("Saved IP address (Reboot to use)\r\n"); 
}*/

/*void cmd_getip(char *arg) {
    unsigned char ip[4];
    getIp(ip);
    printf("Static IP (in EEPROM): %i.%i.%i.%i\r\n", ip[0], ip[1], ip[2], ip[3]);
}*/

//mac is expected to be 6 bytes
void saveMac(unsigned char *mac) {
	int i;
	//copy ID to eeprom
	for (i = 0 ; i < 71; i++)
	  eepromPp[i+4] = i;
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//erase page
	eepromSe[1] = 0x00;
	eepromSe[2] = 0x00;
	eepromSe[3] = 0x00;
	vSPIDoTransfer(1, eepromSe, eepromRx, 4, NULL);
	//wait for finish
	do {
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//write page
	eepromPp[1] = 0x00;
	eepromPp[2] = 0x00;
	eepromPp[3] = 0x00;
	vSPIDoTransfer(1, eepromPp, eepromRx, 74/*52*/, NULL);	
	do {  //wait for finish
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);

//  new debug
	for (i = 0 ; i < 71; i++)
	  eepromPp[i+4] = i;
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//erase page
	/*
	eepromSe[1] = 0x00;
	eepromSe[2] = 0x00;
	eepromSe[3] = 0x10;
	vSPIDoTransfer(1, eepromSe, eepromRx, 4, NULL);
	//wait for finish
	do {
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
	*/
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//write page
	eepromPp[1] = 0x00;
	eepromPp[2] = 0x00;
	eepromPp[3] = 0x46;
	vSPIDoTransfer(1, eepromPp, eepromRx, 74/*52*/, NULL);	
	do {  //wait for finish
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);



    printf("finish 00 and 10 page SaveMAC \r\n"); 
}

void getMacInit(unsigned char *mac) {
    int i;
	//read page
	eepromRead[1] = 0x00;
	eepromRead[2] = 0x10;
	eepromRead[3] = 0x00;
	vSPIDriverTransaction(1, eepromRead, eepromRx, 10);
	for (i = 0; i < 6; i++)
	    mac[i] = eepromRx[i+4];
	//wait for NSS to rise
	while (AT91C_BASE_SPI0->SPI_SR & (1 << 8));
}

void getMac(unsigned char *mac) {
    int i;
	//read page
	eepromRead[1] = 0x00;
	eepromRead[2] = 0x00;
	eepromRead[3] = 0x00;
	vSPIDoTransfer(1, eepromRead, eepromRx, 75, NULL); /* data count + 4*/
	for (i = 0; i < 70; i++){
	    mac[i] = eepromRx[i+4];
	  }
	  mac[0] = 0xAA;
  // new add 
	eepromRead[1] = 0x00;
	eepromRead[2] = 0x00;
	eepromRead[3] = 0x30; // 48
	Delay100NCycles(200);

	// get 40 
	vSPIDoTransfer(1, eepromRead, eepromRx, 22+1+4, NULL); 
	for (i = 0; i < 23; i++){
	    mac[i+0x30] = eepromRx[i+4];
	  }
  // finish

	eepromRead[1] = 0x00;
	eepromRead[2] = 0x20;
	eepromRead[3] = 0x00;
	Delay100NCycles(200);
	vSPIDoTransfer(1, eepromRead, eepromRx, 75, NULL); /* data count + 4*/
	for (i = 0; i < 70; i++){
	    mac[i+70] = eepromRx[i+4];
	  }
	  mac[70] = 0xAA;
  // new add 
	eepromRead[1] = 0x00;
	eepromRead[2] = 0x20;
	eepromRead[3] = 0x30; // 48
	Delay100NCycles(200);

	// get 40 
	vSPIDoTransfer(1, eepromRead, eepromRx, 22+1+4, NULL); 
	for (i = 0; i < 23; i++){
	    mac[i+70+0x30] = eepromRx[i+4];
	  }
  // finish
}

void cmd_setmac(char *arg) {
    unsigned int macl[6];
    unsigned char mac[6];
	short s;
    int i;
#if 0
    if (sscanf(arg, "%2x:%2x:%2x:%2x:%2x:%2x", (macl + 0), (macl + 1), (macl + 2), (macl + 3), (macl + 4), (macl + 5)) != 6) {
        printf("Unable to parse MAC address\r\n");
        return;
    }
    for (i = 0; i < 6; i++)
        mac[i] = macl[i] & 0xff;
#endif 
	s = 256;
	if (s > 255 )
	  printf(" 256 > 255 short size is 2\r\n");
	printf("s = 0x%x\r\n",s);
    
    saveMac(mac);
    printf("Saved MAC address (Reboot to use)\r\n"); 
}

void cmd_getmac(char *arg) {
    unsigned char mac[200];
	unsigned short s = 0;
	s = ntohs(s);
    getMac(mac);
	for (s = 0 ; s <146 ;s += 6 ) 
    printf("MAC%d: %02x:%02x:%02x:%02x:%02x:%02x\r\n",s/6, mac[s], mac[s+1], mac[s+2], mac[s+3], mac[s+4], mac[s+5]);
}

void getIdInit(unsigned char *id) {
    int i;
	//read page
	eepromRead[1] = 0x00;
	eepromRead[2] = 0x00;
	eepromRead[3] = 0x00;
	vSPIDriverTransaction(1, eepromRead, eepromRx, 12);
	for (i = 0; i < 8; i++)
	    id[i] = eepromRx[i+4];
	//wait for NSS to rise
	while (AT91C_BASE_SPI0->SPI_SR & (1 << 8));
}

void cmd_setid(char *arg) {
	int i;
	printf("Setting device ID to \"%s\"...", arg);
	//copy ID to eeprom
	for (i = 0; (i < 8)&&(arg[i] != 0); i++)
		eepromPp[i+4] = arg[i];
	for (; i < 8; i++)
		eepromPp[i+4] = ' ';
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//erase page
	eepromSe[1] = 0x00;
	eepromSe[2] = 0x00;
	eepromSe[3] = 0x00;
	vSPIDoTransfer(1, eepromSe, eepromRx, 4, NULL);
	//wait for finish
	do {
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//write page
	eepromPp[1] = 0x00;
	eepromPp[2] = 0x00;
	eepromPp[3] = 0x00;
	vSPIDoTransfer(1, eepromPp, eepromRx, 12, NULL);	
	//wait for finish
	do {
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
	printf("[DONE]\r\n");
}

void cmd_getid(char *arg) {
	//read page
	eepromRead[1] = 0x00;
	eepromRead[2] = 0x00;
	eepromRead[3] = 0x00;
	vSPIDoTransfer(1, eepromRead, eepromRx, 12, NULL);
	//print read data
	printf("Device ID: \"%c%c%c%c%c%c%c%c\"\r\n", eepromRx[4], eepromRx[5], eepromRx[6], eepromRx[7], eepromRx[8], eepromRx[9], eepromRx[10], eepromRx[11]);
}

int store(unsigned int page,char* data, unsigned char size)
{
	int i,k;
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//erase page
	eepromSe[1] = 0x00;
	eepromSe[2] = 0x00;
	if ( page != 0 ) 
	 eepromSe[2] = 0x20;
	eepromSe[3] = 0x00;

	vSPIDoTransfer(1, eepromSe, eepromRx, 4, NULL);
	//wait for finish
	do {
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
	// finish erase 

	for (i = 0 ; i < EEPROMSPIBlockSize; i++)
	  eepromPp[i+4] = data[i]; 
	 // this is debug code
	 // eepromPp[i+4] = i; 
	//set WREN
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//write page
	eepromPp[1] = 0x00;
	eepromPp[2] = 0x00;
	if ( page != 0 ) 
	 eepromPp[2] = 0x20;
	eepromPp[3] = 0x00;
	vSPIDoTransfer(1, eepromPp, eepromRx, EEPROMSPIBlockSize+4, NULL);	
	do {  //wait for finish
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
	// till it get all the data
	
	// second page
	Delay100NCycles(200);
	for (i = EEPROMSPIBlockSize,k = 0  ; i < size; k++ ,i++)
	  eepromPp[k+4] = data[i];
	 // this is debug code
	 // eepromPp[k+4] = i;
	vSPIDoTransfer(1, &eepromWren, eepromRx, 1, NULL);
	//write page
	eepromPp[3] = EEPROMSPIBlockSize;
	vSPIDoTransfer(1, eepromPp, eepromRx, size-EEPROMSPIBlockSize+1+4, NULL);	
	do {  //wait for finish
		vSPIDoTransfer(1, eepromRdsr, eepromRx, 2, NULL);	
	} while (eepromRx[1] & 1);
	// till it get all the data
}
int fetch(unsigned int page, unsigned char size, char* todata)
{
    int i= 0 , k = 0;
	eepromRead[1] = 0x00;
	if ( page == 0 ) {
	    eepromRead[2] = 0x00; // page num
	}
	else {
	    eepromRead[2] = 0x20;
	}
	eepromRead[3] = 0x00;  
	vSPIDoTransfer(1, eepromRead, eepromRx, size+1+4/*75*/, NULL); /* data count + 4*/
	for (i = 0; i < size/*70*/; i++){
	    todata[i] = eepromRx[i+4];
	  }
  // new add 
	eepromRead[1] = 0x00;
	if ( page == 0 ) {
	    eepromRead[2] = 0x00; // page num
	}
	else {
	    eepromRead[2] = 0x20;
	}
	eepromRead[3] = EEPROMSPIBlockSize; //0x30; // 48
	Delay100NCycles(300);

	// get 40 
	vSPIDoTransfer(1, eepromRead, eepromRx, size-EEPROMSPIBlockSize/*22*/+1+4, NULL); 
	for (i = 0; i < size-EEPROMSPIBlockSize; i++){
	    todata[i+EEPROMSPIBlockSize] = eepromRx[i+4];
	}
	return 0;
}
int ceil(double d) 
{
	int x ; 
	if ( d > (int) d ) 
	  return (int)d+1;


	return (int)d ; 
}
