#ifndef FAN_HEAT_PWM_HEADER
#define FAN_HEAT_PWM_HEADER

/// \file pwmDriver.h header for pwmDriver.c

///with max period this gives ~48kHz with 256 period this gives ~188kHz
#define PWM_FAN_CLK_FREQ 	(MCK/10)
///with max period this gives ~48kHz with 256 period this gives ~188kHz
#define PWM_HEAT_CLK_FREQ 	(MCK/10)

///fan period
#define FAN_PERIOD 	0xff
///heat period
#define HEAT_PERIOD	0xff

///make dutycycle from percentage
#define DUTY_CYCLE_FAN(x) (FAN_PERIOD * (x) / 100)
///make dutycycle from percentage
#define DUTY_CYCLE_HEAT(x) (HEAT_PERIOD * (x) / 100)

//initialize all the pwms to off (but ready to go)
void pwm_init(void);

//set either fan 1 or fan 2 to some duty cycle, use macro
//to make the duty cycle
void set_fan(unsigned char number, unsigned short duty);

//set either heater 1 or heater 2 to some duty cycle, use macro
//to make the duty cycle
void set_heat(unsigned char number, unsigned short duty);

#endif

