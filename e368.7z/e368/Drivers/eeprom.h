#ifndef EEPROM_INCLUSION_GUARD
#define EEPROM_INCLUSION_GUARD
void cmd_setip(char *);
void cmd_getip(char *);
void cmd_setid(char *);
void cmd_getid(char *);
void cmd_setmac(char *arg);
void cmd_getmac(char *arg);
void getMacInit(unsigned char *mac);
void getIpInit(unsigned char *ip);
void getIdInit(unsigned char *id);
int store(unsigned int page,char* data, unsigned char size);
int fetch(unsigned int page,unsigned char size, char* todata);
#endif


