/// \file uartDriver.c Driver for the UART interface
/** \file
 * sets up and drives the uart (RS232) output. This is mostly handled by a
 * interrupt driver that pushes data out the queues, but initialization must
 * take place in a thread.
 */


/* Standard includes. */
#include <stdio.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* board file */
#include "Board.h"

/* Usart files */
#include "usart.h"
#include "pio.h"
#include "aic.h"
#include "uartDriver.h"

#include "USB-CDC.h"

#include "pwmDriver.h"
#include "i2cDriver.h"

///base address of the uart
#define USART_ADDR 				AT91C_BASE_US0
///baud rate to use for the uart
#define BAUD_RATE				115200

///uart TX queue
xQueueHandle xUartTXQueue = NULL;
///uart RX queue
xQueueHandle xUartRXQueue = NULL;

void uartUIInit(void);

///Initialize the uart interface
void uartUIInit(void) {
    extern void ( vUART_ISR_Wrapper )( void );

    //setup the UART
    USART_Configure(USART_ADDR, USART_MODE_ASYNCHRONOUS, BAUD_RATE, MCK);
    USART_SetTransmitterEnabled(USART_ADDR, 1);
    USART_SetReceiverEnabled(USART_ADDR, 1);

    //setup the RX interupt
    AIC_ConfigureIT(AT91C_ID_US0, AT91C_AIC_SRCTYPE_INT_HIGH_LEVEL, ( void (*)( void ) )vUART_ISR_Wrapper);
    AT91C_BASE_AIC->AIC_IECR = (1 << AT91C_ID_US0);
    USART_ADDR->US_IER = AT91C_US_RXRDY;
}

///queue a byte to go out the uart interface
void vUartSendByte(char cByte) {
    xQueueSend( xUartTXQueue, &cByte, 0);
    AT91C_BASE_US0->US_IER = AT91C_US_TXRDY;
}

///get a byte from the uart interface
char vUartRecvByte(void) {
    char byte;
    xQueueReceive( xUartRXQueue, &byte, 0);
    return byte;
}

///check how many bytes are waiting to be recieved from the uart interface
unsigned int vUartBytesWaiting(void) {
    if (xUartRXQueue)
        return uxQueueMessagesWaiting(xUartRXQueue);
    return 0;
}

///check how many bytes are waiting to go out the uart interface
unsigned int vUartTxBufferSize(void) {
    if (xUartTXQueue)
        return uxQueueMessagesWaiting(xUartTXQueue);
    return 0;
}

///UART driver code, just initializes then suspends, ISR handles everything
void vUartDriver( void *pvParameters ) {
    int lsb, msb;
    unsigned short value;
    char buffer[128];
    unsigned int i;
	//setup task tag
	vTaskSetApplicationTaskTag(NULL, (void *)3);
    
    //setup queues
    /* Create the queues used to hold Rx and Tx characters. */
    xUartTXQueue = xQueueCreate( uartQUEUE_LENGTH + 2, ( unsigned char ) sizeof( signed char ) );
    xUartRXQueue = xQueueCreate( uartQUEUE_LENGTH + 2, ( unsigned char ) sizeof( signed char ) );

    uartUIInit();

	vTaskSuspend(NULL); //suspend ourselves, we don't need to do anything
	//XXX: perhaps remove the thread, or do init somewhere else
    /* Loop forever */
    for( ;; ) {
        

        /*I2CReadThermalDeviceRegister(I2C_PORT1, 0x4C, 0x01, &msb);
        I2CReadThermalDeviceRegister(I2C_PORT1, 0x4C, 0x10, &lsb);
        value = (msb << 8) + lsb;
        printf("Remote: %i (0x%04X)\r\n", value, value);

        I2CReadThermalDeviceRegister(I2C_PORT1, 0x4C, 0x00, &lsb);

        printf("Local: %i (0x%04X)\r\n", lsb, lsb);

        while (!readline(buffer));
        printf("\r\n");
        printf("You entered \"%s\"\r\n", buffer);*/

        /*while (vUartBytesWaiting()) {
        	cByte=vUartRecvByte();
        	vUSBSendByte(cByte);
        	//vUartSendByte(cByte);
        }
        while (vUSBBytesWaiting()) {
        	cByte=vUSBRecvByte();
        	//vUSBSendByte(cByte);
        	vUartSendByte(cByte);
        }*/
    }
}


