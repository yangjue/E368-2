/*
    FreeRTOS V6.0.5 - Copyright (C) 2010 Real Time Engineers Ltd.

    ***************************************************************************
    *                                                                         *
    * If you are:                                                             *
    *                                                                         *
    *    + New to FreeRTOS,                                                   *
    *    + Wanting to learn FreeRTOS or multitasking in general quickly       *
    *    + Looking for basic training,                                        *
    *    + Wanting to improve your FreeRTOS skills and productivity           *
    *                                                                         *
    * then take a look at the FreeRTOS eBook                                  *
    *                                                                         *
    *        "Using the FreeRTOS Real Time Kernel - a Practical Guide"        *
    *                  http://www.FreeRTOS.org/Documentation                  *
    *                                                                         *
    * A pdf reference manual is also available.  Both are usually delivered   *
    * to your inbox within 20 minutes to two hours when purchased between 8am *
    * and 8pm GMT (although please allow up to 24 hours in case of            *
    * exceptional circumstances).  Thank you for your support!                *
    *                                                                         *
    ***************************************************************************

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public
    License and the FreeRTOS license exception along with FreeRTOS; if not it
    can be viewed here: http://www.freertos.org/a00114.html and also obtained
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/


/* Standard includes. */
#include <stdio.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* board file */
#include "Board.h"

/* lcd files */
#include "lcdDriver.h"
#include "pio.h"
#include "aic.h"

//include USB for debug
#include "usb.h"

/// \file lcdDriver.c main control code for the LCD

///longest amount of time we can wait for the LCD to not be busy
#define BUSY_MAX 1000

///Length of the buffer that stores LCD commands
#define LCD_COMMAND_BUFFER_LENGTH 128

// Masks
///LCD Busy mask
#define MASK_BUSY(x) 	( ( (x) & 0x08 ) >> 3 )
///LCD data high
#define MASK_DB_H(x) 	( ( (x) & 0xF0 ) >> 4 )
///LCD data low
#define MASK_DB_L(x) 	( (x) & 0x0F )

#define NO_OP 		asm ("nop");
///5 NOOPs
#define NO_OP_5 	NO_OP; NO_OP; NO_OP; NO_OP; NO_OP;
///20 NOOPs
#define NO_OP_20 	NO_OP_5; NO_OP_5; NO_OP_5; NO_OP_5;
///100 NOOPs
#define NO_OP_100 	NO_OP_20; NO_OP_20; NO_OP_20; NO_OP_20; NO_OP_20; 

// Commands and protocols
#define RS_COMMAND			0
#define RS_DATA				1
#define RW_WRITE			0
#define RW_READ				1
#define DB_INIT1			0x3
#define DB_INIT2			0x2
#define DB_FUNCTIONSET	 	0x28
#define DB_DISPLAYOFF	 	0x08
#define DB_CLEARDISPLAY		0x01
#define DB_ENTRYMODESET		0x06
#define DB_DISPLAYON	 	0x0C
#define DB_SETADDR			0x80

// Line addresses
#define LINEADDR_N 4
///address for the different lines
static const int lineAddr[LINEADDR_N]	= { 0x00, 0x40, 0x14, 0x54 };

///queue to hold the LCD commands
xQueueHandle xLCDCommandQueue = NULL;
///handle to the LCD driver task so it can be suspended and resumed
xTaskHandle  lcdDriverTask = NULL;

///LCD command struct
typedef struct {
    unsigned char	rs;
    unsigned char	db;
} t_lcdCommand;

static void cmdBufferAdd(unsigned char rs, unsigned char db);
static void writeFull(unsigned char rs, unsigned char data);
static void writeHalf(unsigned char rs, unsigned char data);
static void readHalf(unsigned char rs, unsigned char* pdata);
int isBusy(void);

static int lcd_flush(unsigned int timeout_ms);
int lcd_init(void);
void Delay100NCycles(unsigned int num);

///delays a specific amount of time
/**
	This function will wait for a certain number of
	cycles, it is here because of the percise timing
	requirements when sending commands to the LCD.

	NOTE: Timing is not guarenteed if we are not in a critical
	section
	\param num number of 100cycles to wait
 */
void Delay100NCycles(unsigned int num) {
    unsigned int i = 0;
    do {
    	NO_OP_100;
        i++;
    } while(i < num);
}

///Flushes the LCD buffer
/**
	will wait timeout_ms while trying to let the buffer flush
	\param timeout_ms amount of time to wait in MS for a timeout
	\return -1 on timeout, 0 on flushed buffer
 */ 
//XXX: Fix flush to restart the driver thread
int lcd_flush(unsigned int timeout_ms) {
    unsigned int busy_i = 0;
    portTickType xLastWakeTime;
    const portTickType xFrequency = portTICK_RATE_MS;
    xLastWakeTime = xTaskGetTickCount();
    while ((uxQueueMessagesWaiting(xLCDCommandQueue))&&(busy_i < timeout_ms)) {
        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }

    if (busy_i >= timeout_ms)
        return -1;

    return 0;
}

///Add a command to the buffer
/**
	Adds a command to the buffer, this is used to send
	information to the LCD
 */
void cmdBufferAdd( unsigned char rs, unsigned char db) {
    t_lcdCommand command;

    if (uxQueueMessagesWaiting(xLCDCommandQueue) == LCD_COMMAND_BUFFER_LENGTH)
        while (lcd_flush(BUSY_MAX));

    command.rs	= rs;
    command.db	= db;

    xQueueSend(xLCDCommandQueue, &command, 0);

    //resume the LCD task
    if (lcdDriverTask != NULL)
	   vTaskResume(lcdDriverTask);
}

/*
	Performs a half read, note that there are NOPs in here,
	it will take longer than expected if an interrupt or
	context switch occurs.

	TODO: 	Consider using a high-accuracy timer instead
			so that contex switching will not effect timing
 */
void readHalf( unsigned char rs, unsigned char* pdata ) {
    //Disable DBx at PA5~PA8 output and enable PIOA clk to read PIO's pin status
    AT91C_BASE_PIOA->PIO_ODR = (0xf << 5);

    if (rs)
        AT91C_BASE_PIOB->PIO_SODR = (1 << 21); //(RS = rs)
    else
        AT91C_BASE_PIOB->PIO_CODR = (1 << 21);

    AT91C_BASE_PIOB->PIO_SODR = (1 << 20) ; //(RW = 1)

    //MCLK = 48M, delay 7 cycles -- more than 140ns
    NO_OP_5;
    NO_OP;
    NO_OP;

    AT91C_BASE_PIOB->PIO_SODR = (1 << 19) ; //(E = 1)

    //Delay 16 cycles -- more than 320ns
    NO_OP_5;
    NO_OP_5;
    NO_OP_5;
    NO_OP;

    //Read data
    *pdata = (unsigned char) ((AT91C_BASE_PIOA->PIO_PDSR) >> 5);

    //MCLK = 48M, delay 7 cycles -- more than 140ns
    NO_OP_5;
    NO_OP;
    NO_OP;
    AT91C_BASE_PIOB->PIO_CODR = (1 << 19) ; //(E = 0)

    //Delay 25 cycles -- more than 500ns
    NO_OP_20;
    NO_OP_5;
}

///Writes a command to the LCD
void writeFull(unsigned char rs, unsigned char data) {
    writeHalf( rs, MASK_DB_H( data ) );
    writeHalf( rs, MASK_DB_L( data ) );
}

///Writes half a command to the LCD
void writeHalf(unsigned char rs, unsigned char data) {
    //enable DBx at PA5~PA8 output
    AT91C_BASE_PIOA->PIO_OER = (0xf << 5);

    //-------------------------------------------
    //control LCD
    // RS at PB21, RW at PB20, E at PB19
    //-------------------------------------------

    if (rs)
        AT91C_BASE_PIOB->PIO_SODR = (1 << 21); //(RS = rs)
    else
        AT91C_BASE_PIOB->PIO_CODR = (1 << 21);

    AT91C_BASE_PIOB->PIO_CODR = (1 << 20) ; //(RW = 0)

    //MCLK = 48M, delay 7 cycles -- more than 140ns
    NO_OP_5;
    NO_OP;
    NO_OP;

    AT91C_BASE_PIOB->PIO_SODR = (1 << 19) ; //(E = 1)
    AT91C_BASE_PIOA->PIO_ODSR = (data << 5) ; //(DBx = data)

    //delay 23 cycles -- more than 450ns
    NO_OP_20;
    NO_OP;
    NO_OP;
    NO_OP;

    AT91C_BASE_PIOB->PIO_CODR = (1 << 19) ; //(E = 0)

    //Delay 25 cycles -- more than 500ns
    NO_OP_20;
    NO_OP_5;

    //Disable DBx at PA5~PA8 output
    AT91C_BASE_PIOA->PIO_ODSR = 0;
    AT91C_BASE_PIOA->PIO_ODR = (0xf << 5);
}


///alias for lcd_print
inline int lcd_printpgm(unsigned int line, unsigned int pos, const char* st, unsigned int n) {
    return lcd_print(line, pos, st, n);
}

///prints a string to LCD
/**
	Sends a string to the lcd, note that if n > strlen(st) then it will clear the
	characters following the string
 */
int lcd_print(unsigned int line, unsigned int pos, const char* st, unsigned int n) {
    unsigned int i = 0;

    if (line >= LINEADDR_N)
        return -1;

    cmdBufferAdd(RS_COMMAND, DB_SETADDR|(lineAddr[line] + pos));

    for (i = 0; i < n; i++) {
        if (i >= strlen(st))
            cmdBufferAdd( RS_DATA, ' ' );
        else {
            cmdBufferAdd( RS_DATA, st[i] );
        }
    }

    return 0;
}


///checks if the LCD is busy or not. Returns 0 if not busy.
int isBusy( void ) {
    unsigned char temp	= 0;
    unsigned char busy	= 0;

    readHalf( 0, &temp );
    busy = MASK_BUSY( temp );
    readHalf( 0, &temp );

    return busy;
}

///Initialize LCD
/**
	Initializes the LCD hardware

	This MUST be run within a critical section

	TODO: 	currently must be called twice (for unknown reasons), that should
			be fixed
 */
int lcd_init( void ) {
    //initialize the bus, make control lines output 0
    AT91C_BASE_PIOB->PIO_CODR = (1 << 19) ; //(E = 0)
    AT91C_BASE_PIOB->PIO_CODR = (1 << 20) ; //(RW = 0)
    AT91C_BASE_PIOB->PIO_CODR = (1 << 21) ; //(RS = 0)
    //AT91C_BASE_PIOA->PIO_ODSR = (0 << 5) ; //(DBx = 0)

    // wait more than 15ms
    //vTaskDelay( portTICK_RATE_MS * 15 );
    Delay100NCycles(7200);

    writeHalf( RS_COMMAND, DB_INIT1 );

    // wait more than 4.1ms
    //vTaskDelay( (int)(portTICK_RATE_MS * 5) );
    Delay100NCycles( 1980 );

    writeHalf( RS_COMMAND, DB_INIT1 );

    // wait more than 100us
    //vTaskDelay( (int)(portTICK_RATE_MS * 1) );
    Delay100NCycles( 48 );

    writeHalf( RS_COMMAND, DB_INIT1 );

    // wait more than 100us
    //vTaskDelay( (int)(portTICK_RATE_MS * 1 ) );
    Delay100NCycles( 48 );

    writeHalf( RS_COMMAND, DB_INIT2 );

    // wait more than 100us
    //vTaskDelay( (int)(portTICK_RATE_MS * 1 ) );
    Delay100NCycles( 48 );

    //final initialization
    writeFull( RS_COMMAND, DB_FUNCTIONSET );

    //for these we must wait until the LCD is ready
    while (isBusy());
    writeFull( RS_COMMAND, DB_DISPLAYOFF );
    while (isBusy());
    writeFull( RS_COMMAND, DB_CLEARDISPLAY );
    while (isBusy());
    writeFull( RS_COMMAND, DB_ENTRYMODESET );
    while (isBusy());
    writeFull( RS_COMMAND, DB_DISPLAYON );

    return 0;
}

///Thread that handles sending commands to the LCD
/**
	LCD Driver thread, this will wait for commands and dispatch them
	as needed.
 */
void vLCDDriver(void *pvParameters) {
	//setup task tag
	vTaskSetApplicationTaskTag(NULL, (void *)1);
    //setup queue
    /* Create the queues used to hold LCD messages. */
    xLCDCommandQueue = xQueueCreate( LCD_COMMAND_BUFFER_LENGTH, ( unsigned char ) sizeof( t_lcdCommand ) );
    
	lcdDriverTask = xTaskGetCurrentTaskHandle();
    //enter critical section so that interupts/context switches don't mess with the timing
    portENTER_CRITICAL();
    //init lcd hardware
    /*
    	this is run twice because the init is actually broken
      	TODO: Fix this so we only need to call init once
      	The init code is from the original sources
     */
    lcd_init();
    lcd_init();
    portEXIT_CRITICAL();

    //initial string on LCD
	lcd_print(0, 0, "ID:", 3);
	if (boardId[0]==0xff)
		lcd_print(0, 4, "Not Set", 8);
	else
		lcd_print(0, 4, boardId, 8);
	lcd_print(0, 14, "v" E368_FIRMWARE_VERSION, 6);

    /* Loop forever */
    for( ;; ) {
        //check if there are any commands to go out, or if we are busy
        if ((uxQueueMessagesWaiting(xLCDCommandQueue))) {
        	while (isBusy()); //wait for LCD to clear command
            //get next command
            t_lcdCommand command;
            xQueueReceive( xLCDCommandQueue, &command, 0);

            //send next command
            writeFull(command.rs, command.db);
        }
        else {
			//suspend the task until a new thing comes in
			vTaskSuspend(NULL);
		}
    }
}


