/// \file spiDriver.c driver code for the SPI
/**
 * Drives the SPI interface. Note that the SPI interface is driven by
 * transactions, which call a callback function on completion.
 */


/* Standard includes. */
#include <stdio.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* board file */
#include "Board.h"

/* spifiles */
#include "aic.h"
#include "spi.h"
#include "spiDriver.h"

#include "USB-CDC.h"

///SPI buffer length
#define SPI_TRANSFER_BUFFER_LENGTH 16

#define AT91C_SPI_DLY8 ( 0x8 << 24)
#define AT91C_SPI_SCBR48 (0x30 << 8)
#define AT91C_SPI_DLYBS8 ( 0x8 << 24)
#define AT91C_SPI_DLYBCT8 ( 0x8 << 24)
#define AT91C_SPI_DLYBCT48 (0xff << 24)

///queue for the SPI buffer
xQueueHandle xSPITransferQueue = NULL;
///task handle for the SPI driver
xTaskHandle  spiDriverTask = NULL;

unsigned char spiInitDone = 0;

int spi_init(void);


///Initializes the SPI hardware
int spi_init(void) {
    //init the spi hardware
    //config SPI0, master, chip select variable, and delay 0x8
    SPI_Configure(AT91C_BASE_SPI0, AT91C_ID_SPI0, AT91C_SPI_MSTR  | AT91C_SPI_PS_VARIABLE | AT91C_SPI_DLY8);
    //config SPI0, CS = 0, clk polarity, clk phase, datawidth, clk freq
    SPI_ConfigureNPCS(AT91C_BASE_SPI0, 0, AT91C_SPI_NCPHA | AT91C_SPI_BITS_16 | AT91C_SPI_SCBR48 | AT91C_SPI_DLYBS8 | AT91C_SPI_DLYBCT48);
    //config SPI0, CS = 2, clk polarity, clk phase, datawidth, clk freq
    SPI_ConfigureNPCS(AT91C_BASE_SPI0, 2, AT91C_SPI_NCPHA | AT91C_SPI_BITS_16 | AT91C_SPI_SCBR48 | AT91C_SPI_DLYBS8 | AT91C_SPI_DLYBCT48);
    //config SPIO, CS = 1, clk polarity, clk phase, datawidth, clk freq, CSAAT
    SPI_ConfigureNPCS(AT91C_BASE_SPI0, 1, AT91C_SPI_NCPHA | AT91C_SPI_BITS_8 | AT91C_SPI_SCBR48 | AT91C_SPI_DLYBS8 | AT91C_SPI_DLYBCT8);
    //enable SPI0
    SPI_Enable(AT91C_BASE_SPI0);

    return 0;
}

///Add an SPI Transfer
/**
	Adds an SPI transfer, will block if buffer is full
	\param trans transfer to add (make sure it doesn't go out of scope)
 */
void vSPIAddTransfer(spi_transfer *trans) {
    while (uxQueueMessagesWaiting(xSPITransferQueue) == SPI_TRANSFER_BUFFER_LENGTH) {
        portYIELD();
    }

    xQueueSend( xSPITransferQueue, trans, 0);
	
	//if we are in the semi-critical section (or asleep), try to resume until it wakes up
	if (spiDriverTask != NULL)
		vTaskResume(spiDriverTask);
}

///Performs an SPI transfer (will block until it's completed)
/**
	Adds and SPI transfer, will block if buffer is full, waits for finish, no callback avaliable
	can only be called from one thread at a time, keep that in mind.
	
 */
void vSPIDoTransfer(unsigned char cs, unsigned short *tx, unsigned short *rx, unsigned char n, void (*callback)(spi_transfer *trans)) {
    spi_transfer trans = {cs, tx, rx, n, callback, xTaskGetCurrentTaskHandle()};
    //add the transfer with current thread to wake up
    vSPIAddTransfer(&trans);
    //suspend current thread, wait for wake up from spi driver
    vTaskSuspend(trans.threadToWake);
}

///Non-threaded version of the code to run SPI before the scheduler starts
/**
  	This function enables getting the EEPROM address
	*before* starting the scheduler

	WARNING: DO NOT CALL ONCE SCHEDULER IS STARTED
	(IE FROM A THREAD) UNLESS YOU ARE SURE OF WHAT
	YOU ARE DOING
 */
void vSPIDriverTransaction(unsigned char cs, unsigned short *tx, unsigned short *rx, unsigned short l) {
	int i;
	if (!spiInitDone)
		spi_init();
	spiInitDone = 1;
	for (i = 0; i < l; i++) {
		SPI_Write(AT91C_BASE_SPI0, cs, tx[i]);
		rx[i] = SPI_Read(AT91C_BASE_SPI0);
	}
}

///Main SPI driver thread
/**
	This is the driver that handles all the SPI setup and
	transfers.
 */
void vSPIDriver(void *pvParameters) {
    unsigned int i;
    
    //setup task tag
	vTaskSetApplicationTaskTag(NULL, (void *)2);
	

    /* Create the queues used to hold SPI messages. */
    xSPITransferQueue = xQueueCreate( SPI_TRANSFER_BUFFER_LENGTH, ( unsigned char ) sizeof( spi_transfer ) );
	
	if (!spiInitDone)
	    spi_init();

	spiDriverTask = xTaskGetCurrentTaskHandle();

	spiInitDone = 1;

    /* Loop forever */
    for( ;; ) {
        //make work still
        if (uxQueueMessagesWaiting(xSPITransferQueue)) {
            //get next transfer
            spi_transfer trans;
            xQueueReceive( xSPITransferQueue, &trans, 0);

            //do next transfer
            for (i = 0; i < trans.length; i++) {
                SPI_Write(AT91C_BASE_SPI0, trans.chipselect, trans.txData[i]);
                trans.rxData[i] = SPI_Read(AT91C_BASE_SPI0);
            }
            //call callback if needed
            if (trans.callback)
                trans.callback(&trans);
            if (trans.threadToWake != NULL)
            	vTaskResume(trans.threadToWake);
        } else {
            //yield the thread
			if (!uxQueueMessagesWaiting(xSPITransferQueue)) {
				vTaskDelay(10);
	            //vTaskSuspend(NULL);
			}
        }
    }
}


