//------------------------------------------------------------------------------
//  _NVRM_COPYRIGHT_BEGIN_
//
//   Copyright 1993-2008 by NVIDIA Corporation.  All rights reserved.  All
//   information contained herein is proprietary and confidential to NVIDIA
//   Corporation.  Any use, reproduction, or disclosure without the written
//   permission of NVIDIA Corporation is prohibited.
//
//   _NVRM_COPYRIGHT_END_
//------------------------------------------------------------------------------
/// \file i2cDriver.c driver functions to abstract the i2c interface
#include "board.h"
#include "i2cDriver.h"

#include "sensors.h"

#define I2C_MULTI_TIMEOUT 100

void I2CSwitchPort(I2CPORTID portid);

///initialize the I2C hardware (must be called before running any other i2c functions)
void I2CInitialize(void) {
    // Enable the peripheral clock in the PMC
    AT91C_BASE_PMC->PMC_PCER = (1 << AT91C_ID_TWI);

    // twi clock 100KHz, master clock 48MHz, set master enable
    AT91C_BASE_TWI->TWI_CR = 0x80;
    AT91C_BASE_TWI->TWI_CWGR = 0xeded;
    AT91C_BASE_TWI->TWI_CR = AT91C_TWI_MSEN;
}

///Switch to the specified I2C bus (controls the i2c mux)
void I2CSwitchPort(I2CPORTID portid) {
    if (portid == I2C_PORT1) {
        //Switch to I2C1. I2C1_SEL = PA30, I2C2_SEL = PA27, high active
        AT91C_BASE_PIOA->PIO_CODR	= (1 << 27);
        AT91C_BASE_PIOA->PIO_SODR	= (1 << 30);
    } else {
        //Switch to I2C2. I2C1_SEL = PA30, I2C2_SEL = PA27, high active
        AT91C_BASE_PIOA->PIO_SODR	= (1 << 27);
        AT91C_BASE_PIOA->PIO_CODR	= (1 << 30);
    }
}

static unsigned int t_stamp;

///Writes an I2C register
/**
	Writes to an i2c device
	\param portid which bus to use
	\param adr device address
	\param reg register to write
	\param value value to write to the register
	\return 0 on failure
*/
unsigned char I2CWriteThermalDeviceRegister(I2CPORTID portid, unsigned char adr, unsigned char reg, int value) {
    //switch the I2C mux to the appropriate port
    I2CSwitchPort(portid);

    //set device slave addr, internal addr size, transmit direction-write
    AT91C_BASE_TWI->TWI_MMR = (adr << 16) | 0x00000100;

    //set internal addr
    AT91C_BASE_TWI->TWI_IADR = reg;

    //load transmit register
    AT91C_BASE_TWI->TWI_THR = value;

    //read and check status register
    if (AT91C_BASE_TWI->TWI_SR & 0x100) {
        AT91C_BASE_TWI->TWI_CR = 0x2;
        return 0;
    }
	
	t_stamp = xTaskGetTickCount();
    while (!(AT91C_BASE_TWI->TWI_SR & 0x4)) {
		if (xTaskGetTickCount() > t_stamp + I2C_MULTI_TIMEOUT)
			return 0;
	}

	t_stamp = xTaskGetTickCount();
    while (!(AT91C_BASE_TWI->TWI_SR & 0x1)) {
		if (xTaskGetTickCount() > t_stamp + I2C_MULTI_TIMEOUT)
			return 0;
	}

    return 1;
}

///Read an I2C register
/**
	Reads from an i2c device
	\param portid which bus to use
	\param adr device address
	\param reg register to read
	\param value place to write the read value
	\return 0 on failure
*/
unsigned char I2CReadThermalDeviceRegister(I2CPORTID portid, unsigned char adr, unsigned char reg, int *value) {
    //switch the I2C mux to the appropriate port
    I2CSwitchPort(portid);

    //send stop first because just one byte to send
    AT91C_BASE_TWI->TWI_CR = 0x2;

    //set device slave addr, internal addr size, transmit direction-read
    AT91C_BASE_TWI->TWI_MMR = (adr << 16) | 0x00001100;

    //set internal addr
    AT91C_BASE_TWI->TWI_IADR = reg;

    //start the transfer
    AT91C_BASE_TWI->TWI_CR = 0x1;

    Delay100NCycles(1000);
	
    //read and check status register
    if ((AT91C_BASE_TWI->TWI_SR) & 0x00000100)
        return 0;
	
	t_stamp = xTaskGetTickCount();
    while (!(AT91C_BASE_TWI->TWI_SR & 0x2)) {
		if (xTaskGetTickCount() > t_stamp + I2C_MULTI_TIMEOUT)
			return 0;
	}

    *value = AT91C_BASE_TWI->TWI_RHR;

	t_stamp = xTaskGetTickCount();
    while (!(AT91C_BASE_TWI->TWI_SR & 0x1)) {
		if (xTaskGetTickCount() > t_stamp + I2C_MULTI_TIMEOUT)
			return 0;
	}

    return 1;
}

///table for which sensors were found
unsigned char I2CSensorsFound[2][I2C_DEVS_N];

///Scan the i2c bus for known sensors
void I2CScanBus(I2CPORTID portid) {
	int i;
	int deviceId = 0;
	int temp;
	for (i = 0; i < I2C_DEVS_N; i++) {
		I2CSensorsFound[portid][i] = 0;
		if ((I2CReadThermalDeviceRegister(portid, i2c_devices[i].addr, i2c_devices[i].pRegTable->reg_rid, &deviceId))&&(deviceId == i2c_devices[i].deviceId)) {
			//mark that it exists
			I2CSensorsFound[portid][i] = 1;
		}
	}
}

///check for a specific i2c sensor
unsigned int I2CCheckSensor(I2CPORTID portid, unsigned char adr, unsigned char reg, int devid) {
	int deviceId = 0;
	return ((I2CReadThermalDeviceRegister(portid, adr, reg, &deviceId))&&(deviceId == devid));
}

///checks if a specific sensor had been found, must call I2CScanBus first
unsigned char I2CSensorFound(I2CPORTID portid, unsigned int sensor) {
	return I2CSensorsFound[portid][sensor];
}

