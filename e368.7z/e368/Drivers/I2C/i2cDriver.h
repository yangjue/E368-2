//------------------------------------------------------------------------------
//  _NVRM_COPYRIGHT_BEGIN_
//
//   Copyright 1993-2008 by NVIDIA Corporation.  All rights reserved.  All
//   information contained herein is proprietary and confidential to NVIDIA
//   Corporation.  Any use, reproduction, or disclosure without the written
//   permission of NVIDIA Corporation is prohibited.
//
//   _NVRM_COPYRIGHT_END_
//------------------------------------------------------------------------------

#ifndef __I2C_H__
#define __I2C_H__

#define I2C_PORT1 0
#define I2C_PORT2 1

/// \file i2cDriver.h header for i2cDriver.c

// I2C port ids
typedef unsigned int I2CPORTID;


// I2C module
void I2CInitialize(void);
void I2CPerformSTOP(void);
unsigned char I2CWriteThermalDeviceRegister(I2CPORTID portid, unsigned char adr, unsigned char reg, int value);
unsigned char I2CReadThermalDeviceRegister(I2CPORTID portid, unsigned char adr, unsigned char reg, int *value);

unsigned int I2CCheckSensor(I2CPORTID portid, unsigned char adr, unsigned char reg, int devid);

//Scan the i2c bus for known sensors
void I2CScanBus(I2CPORTID portid);

//checks if the sensor had been found, sensor is the table entry number from the i2c table
unsigned char I2CSensorFound(I2CPORTID portid, unsigned int sensor);

#endif  /* __I2C_H__ */


