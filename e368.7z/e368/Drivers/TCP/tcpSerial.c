/*
    FreeRTOS V6.0.5 - Copyright (C) 2010 Real Time Engineers Ltd.

    ***************************************************************************
    *                                                                         *
    * If you are:                                                             *
    *                                                                         *
    *    + New to FreeRTOS,                                                   *
    *    + Wanting to learn FreeRTOS or multitasking in general quickly       *
    *    + Looking for basic training,                                        *
    *    + Wanting to improve your FreeRTOS skills and productivity           *
    *                                                                         *
    * then take a look at the FreeRTOS eBook                                  *
    *                                                                         *
    *        "Using the FreeRTOS Real Time Kernel - a Practical Guide"        *
    *                  http://www.FreeRTOS.org/Documentation                  *
    *                                                                         *
    * A pdf reference manual is also available.  Both are usually delivered   *
    * to your inbox within 20 minutes to two hours when purchased between 8am *
    * and 8pm GMT (although please allow up to 24 hours in case of            *
    * exceptional circumstances).  Thank you for your support!                *
    *                                                                         *
    ***************************************************************************

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public
    License and the FreeRTOS license exception along with FreeRTOS; if not it
    can be viewed here: http://www.freertos.org/a00114.html and also obtained
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/
/// \file tcpSerial.c telnet interface
/** \file
	Implements a basic telnet interface, this runs over the ethernet, to
	the program (atmel) looks like a serial port.
*/

/* Standard includes. */
#include <stdio.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "board.h"

/* Demo includes. */
#include "tcpSerial.h"
#include "SAM7_EMAC.h"

/* lwIP includes. */
#include "lwip/api.h"
#include "lwip/tcpip.h"
#include "lwip/memp.h"
#include "lwip/stats.h"
#include "lwip/dhcp.h"
#include "netif/loopif.h"
#include "USB-CDC.h"

#include "Drivers/LCD/lcdDriver.h"

/* RX and TX queues for the telnet connection */
///TX queue for telnet connection
xQueueHandle xTelnetTXQueue = NULL;
///RX queue for the telnet connection
xQueueHandle xTelnetRXQueue = NULL;

///connection to the client, used to tell if we are connected
struct netconn *pxNewConnection = NULL;

static struct netif EMAC_if;

unsigned char ethernetCableConnected = 0;

///The port on which we listen.
#define webTELNET_PORT		( 23 )

///Delay on close error.
#define webSHORT_DELAY		( 10 )


/*------------------------------------------------------------*/
///Initialize lwIP and the interface layer
void vlwIPInit( void ) {
    /* Initialize lwIP and its interface layer. */
    sys_init();
    mem_init();
    memp_init();
    pbuf_init();
    netif_init();
    ip_init();
    tcpip_init( NULL, NULL );
}

///Queue a byte to go out on the telnet connection
void vTcpSendByte(char cByte) {
    xQueueSend( xTelnetTXQueue, &cByte, 0);
}

///Get a byte from the telnet connection
char vTcpRecvByte(void) {
    char byte;
    xQueueReceive( xTelnetRXQueue, &byte, 0);
    return byte;
}

///Check how many bytes are waiting from the telnet connection
unsigned int vTcpBytesWaiting(void) {
    if (xTelnetRXQueue)
        return uxQueueMessagesWaiting(xTelnetRXQueue);
    return 0;
}

///Check how many bytes are waiting to go out the telnet connection
unsigned int vTcpTxBufferSize(void) {
    if (xTelnetTXQueue)
        return uxQueueMessagesWaiting(xTelnetTXQueue);
    return 0;
}

///Check if a socket is connected
unsigned int vTcpConnected(void) {
    return pxNewConnection != NULL;
}

void printIPAddress(void) {
	printf("%i.%i.%i.%i", 
			EMAC_if.ip_addr.addr & 0xff, 
			(EMAC_if.ip_addr.addr >> 8) & 0xff, 
			(EMAC_if.ip_addr.addr >> 16) & 0xff, 
			(EMAC_if.ip_addr.addr >> 24) & 0xff);
}

void lcdIPAddress(void) {
	char str[16];
	sprintf(str, "%i.%i.%i.%i",
			EMAC_if.ip_addr.addr & 0xff, 
			(EMAC_if.ip_addr.addr >> 8) & 0xff, 
			(EMAC_if.ip_addr.addr >> 16) & 0xff, 
			(EMAC_if.ip_addr.addr >> 24) & 0xff);
	lcd_print(2,0,str,strlen(str));
}

unsigned char ipIsEmpty(void) {
	return ((EMAC_if.ip_addr.addr == 0) || (EMAC_if.ip_addr.addr == 0xffffffff));
}


/*------------------------------------------------------------*/
///Thread that runs the telnet server
void vBasicWEBServer( void *pvParameters ) {
    struct netconn *pxHTTPListener;
    struct ip_addr xIpAddr, xNetMast, xGateway;
    extern err_t ethernetif_init( struct netif *netif );
    static char buffer[tcpQUEUE_LENGTH];
    struct netbuf *pxRxBuffer;
    char *pcRxString;
    char byte;
    unsigned short usLength;
    unsigned int i = 0;
    unsigned int waitTicks;
	unsigned int mscnt = 0;
    
	vTaskSetApplicationTaskTag(NULL, (void *)6);
    /* Parameters are not used - suppress compiler error. */
    ( void ) pvParameters;
	

    /* Create and configure the EMAC interface. */
    //IP4_ADDR(&xIpAddr, emacIPADDR0,  		emacIPADDR1,		emacIPADDR2,		emacIPADDR3);
    //IP4_ADDR(&xNetMast,emacNET_MASK0,		emacNET_MASK1,		emacNET_MASK2,		emacNET_MASK3);
    //IP4_ADDR(&xGateway,emacGATEWAY_ADDR0,	emacGATEWAY_ADDR1,	emacGATEWAY_ADDR2,	emacGATEWAY_ADDR3);

    //netif_add(&EMAC_if, &xIpAddr, &xNetMast, &xGateway, NULL, ethernetif_init, tcpip_input);
	//assumed until it needs to change
	//XXX: attempt to get IP again... this is BUG FIX
	if (((ucIPAddress[0] == 0)&&(ucIPAddress[1] == 0)&&(ucIPAddress[2] == 0)&&(ucIPAddress[3] == 0)) ||
	 	((ucIPAddress[0] == 0xff)&&(ucIPAddress[1] == 0xff)&&(ucIPAddress[2] == 0xff)&&(ucIPAddress[3] == 0xff))) {
	    IP4_ADDR(&xNetMast,0,0,0,0);
		IP4_ADDR(&xIpAddr,0,0,0,0);
	}
	else {
		IP4_ADDR(&xNetMast,255,255,255,0);
		IP4_ADDR(&xIpAddr,ucIPAddress[0],ucIPAddress[1],ucIPAddress[2],ucIPAddress[3]);
	}
	//doesn't need to change
    IP4_ADDR(&xGateway,0,0,0,0);

    netif_add( &EMAC_if, &xIpAddr, &xNetMast, &xGateway, NULL, ethernetif_init, tcpip_input );
    netif_set_default( &EMAC_if );
    /* make it the default interface */
    //netif_set_default(&EMAC_if);
	//get an address
	if (ipIsEmpty()) {
		dhcp_start(&EMAC_if);
	
		//printf("Starting DHCP...\r\n");
		while (EMAC_if.ip_addr.addr==0) {
    	    sys_msleep(DHCP_FINE_TIMER_MSECS);
        	dhcp_fine_tmr();
	        mscnt += DHCP_FINE_TIMER_MSECS;
    	    if (mscnt >= DHCP_COARSE_TIMER_SECS*1000) {
        	    dhcp_coarse_tmr();
        		mscnt = 0;
	        }
    	}
	}
	//printf("DHCP Complete... 0x%08x\r\n", EMAC_if.ip_addr.addr);
    /* bring it up */
    netif_set_up(&EMAC_if);

    /* Create a new tcp connection handle */

    pxHTTPListener = netconn_new( NETCONN_TCP );
    netconn_bind(pxHTTPListener, NULL, webTELNET_PORT );
    netconn_listen( pxHTTPListener );

    //initialize the buffer queues
    xTelnetTXQueue = xQueueCreate( tcpQUEUE_LENGTH + 2, ( unsigned char ) sizeof( signed char ) );
    xTelnetRXQueue = xQueueCreate( tcpQUEUE_LENGTH + 2, ( unsigned char ) sizeof( signed char ) );

    /* Loop forever */
    for( ;; ) {
        /* Wait for connection. */
        pxNewConnection = netconn_accept(pxHTTPListener);

        if(pxNewConnection != NULL) {
            /* Service connection. */
            //write hello message (so system knows it connected correctly
            //netconn_write(pxNewConnection, "E368 Online\r\n", strlen("E368 Online\r\n"), NETCONN_COPY);
            //run until the connection explodes
            while (!netconn_err(pxNewConnection)) {
                //check for outgoing data
                if ((vTcpTxBufferSize() > 64)||((vTcpTxBufferSize() > 0)&&(xTaskGetTickCount() > waitTicks))) {
                    //if (vTcpTxBufferSize() > 64) {
                    //copy buffer to local in line buffer
                    i = 0;
                    while (vTcpTxBufferSize())
                        xQueueReceive(xTelnetTXQueue, &buffer[i++], 0);
                    buffer[i] = 0;
                    netconn_write(pxNewConnection, buffer, i, NETCONN_COPY);
                    waitTicks = xTaskGetTickCount() + (portTICK_RATE_MS * 100);
                }
                //check for incomming data
                else if (uxQueueMessagesWaiting(pxNewConnection->recvmbox)) {
                    //data is waiting
                    pxRxBuffer = netconn_recv( pxNewConnection );
                    if( pxRxBuffer != NULL ) {
                        //get the real data
                        netbuf_data( pxRxBuffer, ( void * ) &pcRxString, &usLength );
                        //push into our buffer
                        for (i = 0; i < usLength; i++) {
                            xQueueSend(xTelnetRXQueue, &pcRxString[i], 0);
                            //auto echo
                            //if (pcRxString[i] != 0x08) //no echo backspace
	                            //xQueueSend(xTelnetTXQueue, &pcRxString[i], 0);
                        }
                        netbuf_delete(pxRxBuffer);
                    }
                }
                //small delay (so we don't own the CPU)
                else {
                    vTaskDelay(webSHORT_DELAY);
                }
            }
            netconn_close(pxNewConnection);
            while( netconn_delete( pxNewConnection ) != ERR_OK )
                vTaskDelay( webSHORT_DELAY );
        }
        pxNewConnection = NULL;
    }
}


