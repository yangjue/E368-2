#ifndef SERIAL_PORT_INCLUSION_GUARD
#define SERIAL_PORT_INCLUSION_GUARD

/// \file serial.h serial.c header

//holds all the important information about a serial port
//that is, how to send and recv bytes, buffers are expected
//to be maintained by the serial port its self.
//
//this helps abstract which hardware interface we are using
///Serial port information
typedef struct serial_port_t {
	///name of serial port
    char *name;
    ///how long the buffer is
    unsigned int buffer_length;
    ///function to send a byte
    /**
    	\param char byte to be sent
    */
    void (*send)(char);
    ///function to get a byte
    /**
    	\return next byte in buffer
    */
    char (*recv)(void);
    ///get how many bytes are waiting to be read in
    /**
    	\return number of bytes waiting in buffer
    */
    unsigned int (*inWaiting)(void);
    ///get how many bytes are waiting to go out
    /**
    	\return number of bytes waiting to be sent
    */
    unsigned int (*outWaiting)(void);
    ///get if we are connected or not
    /**
    	\return 1 == connected, 0 == not
    */
    unsigned int (*connected)(void); //optional
} serial_port;

///Total number of serial ports
#define NUMBER_SERIAL_PORTS 2
#define USB_SERIAL_PORT		0
#define RS232_SERIAL_PORT	1
//#define TCP_SERIAL_PORT		2

extern serial_port serial_ports[2];

//gets the number of bytes that are ready,
//returns the max of all serial devices
unsigned int serialBytesWaiting(void);
char* formatTemp( signed int temp, char* buf );

//nukes all the input buffers
void serialFlushInputBuffers(void);

#endif

