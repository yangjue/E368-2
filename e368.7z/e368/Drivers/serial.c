#include "serial.h"
#include "USB-CDC.h"
#include "uartDriver.h"
//#include "tcpSerial.h"
#include "sensors.h"
/// \file serial.c Serial Port interface

///Dummy 'connected' function for if the port should not block
unsigned int dummyNotConnected(void) {
	return 0;
}

///List of serial ports and thier properties
serial_port serial_ports[2] = {{
        "USB-CDC",
        USB_CDC_QUEUE_SIZE,
        vUSBSendByte,
        vUSBRecvByte,
        vUSBBytesWaiting,
        vUSBTxBufferSize,
        //vUSBConnected
        dummyNotConnected
    },
    {
        "RS232",
        uartQUEUE_LENGTH,
        vUartSendByte,
        vUartRecvByte,
        vUartBytesWaiting,
        vUartTxBufferSize,
        0
  //  },
  //  {
  //      "Ethernet",
 //       tcpQUEUE_LENGTH,
  //      vTcpSendByte,
  //      vTcpRecvByte,
   //     vTcpBytesWaiting,
   //     vTcpTxBufferSize,
   //     vTcpConnected
    }
};

///Get max number of bytes waiting on the serial ports
unsigned int serialBytesWaiting(void) {
	int max = 0;
	int i;
	for (i = 0; i < NUMBER_SERIAL_PORTS; i++)
		if (serial_ports[i].inWaiting() > max)
			max = serial_ports[i].inWaiting();
	return max;
}

///Flush all the input buffers
void serialFlushInputBuffers(void) {
	int i;
	for (i = 0; i < NUMBER_SERIAL_PORTS; i++)
		while (serial_ports[i].inWaiting())
			serial_ports[i].recv();
}

///Format a temperature
/**
	\param temp temp
	\param buf buffer to write the data into
	\return returns buf
*/
char* formatTemp(signed int temp, char* buf) {
    int i = 0;
	
	if (temp == SENSOR_OPEN) {
		buf[0]='N';
		buf[1]='C';
		buf[2]=0;
		return buf;
	}

    if (temp < 0) {
        buf++;
        itoa( -temp, buf );
    } else {
        itoa(temp, buf);
    }
    i	= strlen( buf );
    if (i > 2) {
        buf[i] = buf[i-1];
        buf[i-1] = buf[i-2];
        buf[i-2] = '.';
        buf[i+1] = 0;
    } else if (i == 2) {
        buf[4] = 0;
        buf[3] = buf[1];
        buf[2] = buf[0];
        buf[0] = '0';
        buf[1] = '.';
    } else if (i == 1) {
        buf[4] = 0;
        buf[3] = buf[0];
        buf[2] = '0';
        buf[1] = '.';
        buf[0] = '0';
    }
    if (temp < 0) {
        buf--;
        buf[0] = '-';
    }

    return buf;
}

