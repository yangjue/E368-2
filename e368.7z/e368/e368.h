#ifndef __E368_H__
#define  __E368_H__
short ntohs(short s );
int   ntohl(int i);

#endif
