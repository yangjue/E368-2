#ifndef SAFETY_INCLUSION_GUARD
#define SAFETY_INCLUSION_GUARD

/// \file safety.h Safety task header

void vSafetyTask(void *pvParameters);

extern unsigned char   device_type[] ;
#endif

